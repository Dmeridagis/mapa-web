<?php


$variable01 = 2024;

echo $variable01;







?>