<?php //a partir de este archicvo accedemos y recuperamos para todo

define('HOST','localhost');
define('USER','postgres');
define('PASS','floki');
define('BASE','mapagis');
define('PORT','5432'); // si hay mas de una isntalación de postgres hay que revisar el puerto

?>