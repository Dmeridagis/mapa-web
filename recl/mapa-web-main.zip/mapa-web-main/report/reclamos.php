<?php

include 'libreria.php';

function listaReclamos() {
    $sql = "SELECT id_acciones, tipo, mensaje, ST_AsGeoJSON(geom) AS geom FROM public.reclamos_vecinos";
    $reclamos = consultaGeojson2($sql);
    return $reclamos;
}

echo listaReclamos();

?>
